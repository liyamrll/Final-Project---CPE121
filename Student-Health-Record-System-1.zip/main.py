import tkinter as tk
from tkinter import messagebox, simpledialog

class StudentHealthRecord:
    def __init__(self, student_id, name, age, gender, height, weight, medical_history, current_health_issues):
        self.student_id = student_id
        self.name = name
        self.age = age
        self.gender = gender
        self.height = height
        self.weight = weight
        self.medical_history = medical_history
        self.current_health_issues = current_health_issues

class HealthRecordApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Student Health Record System")
        self.records = []


        self.setup_main_window()

        self.setup_signin_window()

    def setup_main_window(self):

        tk.Label(self.root, text="Student ID:", font=("Times New Roman", 12), bg="yellow", fg="green").grid(row=0, column=0)
        tk.Label(self.root, text="Name:", font=("Times New Roman", 12), bg="yellow", fg="green").grid(row=1, column=0)
        tk.Label(self.root, text="Age:", font=("Times New Roman", 12), bg="yellow", fg="green").grid(row=2, column=0)
        tk.Label(self.root, text="Gender:", font=("Times New Roman", 12), bg="yellow", fg="green").grid(row=3, column=0)
        tk.Label(self.root, text="Height:", font=("Times New Roman", 12), bg="yellow", fg="green").grid(row=4, column=0)
        tk.Label(self.root, text="Weight:", font=("Times New Roman", 12), bg="yellow", fg="green").grid(row=5, column=0)
        tk.Label(self.root, text="Medical History:", font=("Times New Roman", 12), bg="yellow", fg="green").grid(row=6, column=0)
        tk.Label(self.root, text="Current Health Issues:", font=("Times New Roman", 12), bg="yellow", fg="green").grid(row=7, column=0)

    
        self.student_id_entry = tk.Entry(self.root)
        self.student_id_entry.grid(row=0, column=1)

        self.name_entry = tk.Entry(self.root)
        self.name_entry.grid(row=1, column=1)

        self.age_entry = tk.Entry(self.root)
        self.age_entry.grid(row=2, column=1)

        self.gender_entry = tk.Entry(self.root)
        self.gender_entry.grid(row=3, column=1)

        self.height_entry = tk.Entry(self.root)
        self.height_entry.grid(row=4, column=1)

        self.weight_entry = tk.Entry(self.root)
        self.weight_entry.grid(row=5, column=1)

        self.medical_history_entry = tk.Entry(self.root)
        self.medical_history_entry.grid(row=6, column=1)

        self.current_health_issues_var1 = tk.IntVar()
        self.current_health_issues_check1 = tk.Checkbutton(self.root, text="Fever", variable=self.current_health_issues_var1)
        self.current_health_issues_check1.grid(row=7, column=1, sticky="w")

        self.current_health_issues_var2 = tk.IntVar()
        self.current_health_issues_check2 = tk.Checkbutton(self.root, text="Cough", variable=self.current_health_issues_var2)
        self.current_health_issues_check2.grid(row=7, column=2, sticky="w")

        self.current_health_issues_var3 = tk.IntVar()
        self.current_health_issues_check3 = tk.Checkbutton(self.root, text="Headache", variable=self.current_health_issues_var3)
        self.current_health_issues_check3.grid(row=7, column=3, sticky="w")


        self.other_health_issue_var = tk.StringVar()
        tk.Label(self.root, text="Other:").grid(row=7, column=4, sticky="w")
        self.other_health_issue_entry = tk.Entry(self.root, textvariable=self.other_health_issue_var)
        self.other_health_issue_entry.grid(row=7, column=5, sticky="w")


        tk.Button(self.root, text="Add Record", command=self.add_record).grid(row=8, column=0, pady=10)
        tk.Button(self.root, text="Edit Record", command=self.edit_record).grid(row=8, column=2, pady=10)
        tk.Button(self.root, text="Save Edit", command=self.save_edit).grid(row=8, column=3, pady=10)
        tk.Button(self.root, text="View Records", command=self.view_records).grid(row=8, column=5, pady=10, padx=10)
        tk.Button(self.root, text="Search Record", command=self.search_record).grid(row=8, column=4, pady=10, padx=10)
        tk.Button(self.root, text="Delete Record", command=self.delete_record).grid(row=8, column=1, pady=10, padx=10)

        self.root.geometry("500x800")

        self.edit_index = None

    def setup_signin_window(self):
        self.signin_window = tk.Toplevel(self.root)
        self.signin_window.title("Sign In")
        self.signin_window.geometry("300x300")

        tk.Label(self.signin_window, text="Username:").grid(row=0, column=0, padx=10, pady=10)
        tk.Label(self.signin_window, text="Password:").grid(row=1, column=0, padx=10, pady=10)

        self.username_entry = tk.Entry(self.signin_window)
        self.username_entry.grid(row=0, column=1, padx=10, pady=10)

        self.password_entry = tk.Entry(self.signin_window, show="*")
        self.password_entry.grid(row=1, column=1, padx=10, pady=10)

        tk.Button(self.signin_window, text="Sign In", command=self.verify_credentials).grid(row=2, column=0, columnspan=2, pady=10)

    def verify_credentials(self):
        username = "psau_health_cares"
        password = "password"

        entered_username = self.username_entry.get()
        entered_password = self.password_entry.get()

        if entered_username == username and entered_password == password:
            messagebox.showinfo("Success", "Login Successful.")
            self.signin_window.destroy()
            self.root.deiconify()
        else:
            messagebox.showerror("Error", "Invalid Username or Password.")

    def add_record(self):
        student_id = self.student_id_entry.get()
        name = self.name_entry.get()
        age = self.age_entry.get()
        gender = self.gender_entry.get()
        height = self.height_entry.get()
        weight = self.weight_entry.get()
        medical_history = self.medical_history_entry.get()
        current_health_issues = []
        if self.current_health_issues_var1.get():
            current_health_issues.append("Fever")
        if self.current_health_issues_var2.get():
            current_health_issues.append("Cough")
        if self.current_health_issues_var3.get():
            current_health_issues.append("Headache")
        other_issue = self.other_health_issue_var.get().strip()
        if other_issue:
            current_health_issues.append(other_issue)

        if not all((student_id, name, age, gender, height, weight)):
            messagebox.showerror("Error", "Please fill in all required fields.")
            return

        try:
            age = int(age)
            height = float(height)
            weight = float(weight)
        except ValueError:
            messagebox.showerror("Error", "Invalid input for age, height, or weight.")
            return

        record = StudentHealthRecord(student_id, name, age, gender, height, weight, medical_history, current_health_issues)
        self.records.append(record)
        messagebox.showinfo("Success", "Record added successfully.")

        self.clear_entry_fields()

    def edit_record(self):
        selected_index = simpledialog.askinteger("Edit Record", "Enter the index of the record to edit:", parent=self.root)
        if selected_index is None:
            return

        try:
            selected_record = self.records[selected_index - 1]
        except IndexError:
            messagebox.showerror("Error", "Invalid index.")
            return

        self.edit_index = selected_index - 1
        self.student_id_entry.delete(0, tk.END)
        self.student_id_entry.insert(0, selected_record.student_id)
        self.name_entry.delete(0, tk.END)
        self.name_entry.insert(0, selected_record.name)
        self.age_entry.delete(0, tk.END)
        self.age_entry.insert(0, selected_record.age)
        self.gender_entry.delete(0, tk.END)
        self.gender_entry.insert(0, selected_record.gender)
        self.height_entry.delete(0, tk.END)
        self.height_entry.insert(0, selected_record.height)
        self.weight_entry.delete(0, tk.END)
        self.weight_entry.insert(0, selected_record.weight)
        self.medical_history_entry.delete(0, tk.END)
        self.medical_history_entry.insert(0, selected_record.medical_history)

        for issue in selected_record.current_health_issues:
            if issue == "Fever":
                self.current_health_issues_var1.set(1)
            elif issue == "Cough":
                self.current_health_issues_var2.set(1)
            elif issue == "Headache":
                self.current_health_issues_var3.set(1)
            else:
                self.other_health_issue_var.set(issue)

    def save_edit(self):
        if self.edit_index is None:
            messagebox.showerror("Error", "No record selected to edit.")
            return

        student_id = self.student_id_entry.get()
        name = self.name_entry.get()
        age = self.age_entry.get()
        gender = self.gender_entry.get()
        height = self.height_entry.get()
        weight = self.weight_entry.get()
        medical_history = self.medical_history_entry.get()
        current_health_issues = []
        if self.current_health_issues_var1.get():
            current_health_issues.append("Fever")
        if self.current_health_issues_var2.get():
            current_health_issues.append("Cough")
        if self.current_health_issues_var3.get():
            current_health_issues.append("Headache")
        other_issue = self.other_health_issue_var.get().strip()
        if other_issue:
            current_health_issues.append(other_issue)

        if not all((student_id, name, age, gender, height, weight)):
            messagebox.showerror("Error", "Please fill in all required fields.")
            return

        try:
            age = int(age)
            height = float(height)
            weight = float(weight)
        except ValueError:
            messagebox.showerror("Error", "Invalid input for age, height, or weight.")
            return

        record = StudentHealthRecord(student_id, name, age, gender, height, weight, medical_history, current_health_issues)
        self.records[self.edit_index] = record
        messagebox.showinfo("Success", "Record edited and saved successfully.")

        self.clear_entry_fields()
        self.edit_index = None

    def delete_record(self):
        if not self.records:
            messagebox.showinfo("No Records", "No records found to delete.")
            return

        index = simpledialog.askinteger("Delete Record", "Enter the index of the record to delete:", parent=self.root)

        if index is None:
            return

        try:
            del self.records[index - 1]
            messagebox.showinfo("Success", "Record deleted successfully.")
        except IndexError:
            messagebox.showerror("Error", "Invalid index.")

    def search_record(self):
        if not self.records:
            messagebox.showinfo("No Records", "No records found to search.")
            return

        search_name = simpledialog.askstring("Search Record", "Enter the name to search:", parent=self.root)

        if search_name is None:
            return

        found_records = []
        for record in self.records:
            if record.name.lower() == search_name.lower():
                found_records.append(record)

        if found_records:
            records_text = ""
            for idx, record in enumerate(found_records, start=1):
                records_text += f"Student ID: {record.student_id}\n"
                records_text += f"Name: {record.name}, Age: {record.age}, Gender: {record.gender}, Height: {record.height}, Weight: {record.weight}\n"
                records_text += f"Medical History: {record.medical_history}\n"
                records_text += f"Current Health Issues: {', '.join(record.current_health_issues)}\n"
            messagebox.showinfo("Search Results", records_text)
        else:
            messagebox.showinfo("Search Results", f"No records found for {search_name}.")

    def view_records(self):
        if not self.records:
            messagebox.showinfo("No Records", "No records found.")
            return

        records_text = ""
        for idx, record in enumerate(self.records, start=1):
            records_text += f"{idx}. Student ID: {record.student_id}, Name: {record.name}, Age: {record.age}, Gender: {record.gender}, Height: {record.height}, Weight: {record.weight}\n"
            records_text += f"Medical History: {record.medical_history}\n"
            records_text += f"Current Health Issues: {', '.join(record.current_health_issues)}\n\n"

        messagebox.showinfo("Records", records_text)

    def clear_entry_fields(self):
        self.student_id_entry.delete(0, tk.END)
        self.name_entry.delete(0, tk.END)
        self.age_entry.delete(0, tk.END)
        self.gender_entry.delete(0, tk.END)
        self.height_entry.delete(0, tk.END)
        self.weight_entry.delete(0, tk.END)
        self.medical_history_entry.delete(0, tk.END)
        self.current_health_issues_var1.set(0)
        self.current_health_issues_var2.set(0)
        self.current_health_issues_var3.set(0)
        self.other_health_issue_var.set("")


root = tk.Tk()
app = HealthRecordApp(root)
root.withdraw()
root.mainloop()